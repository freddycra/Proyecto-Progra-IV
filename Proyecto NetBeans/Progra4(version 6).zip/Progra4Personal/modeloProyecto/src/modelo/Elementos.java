package modelo;

public class Elementos {
    public static int id_Categoria_Requerido = 0;
    public static int administrador_trabajando = 0;
    public static int administrador_autorizando = 0; //1->Empresas 2->Oferentes 0->En espera
}
